/**
 * @package 	WordPress
 * @subpackage 	Dental Clinic
 * @version 	1.0.0
 * 
 * Theme Information
 * Created by CMSMasters
 * 
 */


Version 1.0: Release!

